<?php include 'header.php';?>

	<div class="container">
			<div class="row">
				<div class="col-md-12">
					<form action="/action_page.php">
						<div class="form-group row">
							<label for="inputEmail3" class="col-md-4 text-right col-form-label">Name <span>*</span></label>
							<div class="col-sm-6">
							<input type="text" class="form-control" id="inputEmail3" placeholder="Type your name">
							</div>
						</div>

						<div class="form-group row">
							<label for="inputEmail3" class="col-md-4 text-right col-form-label">Email<span>*</span></label>
							<div class="col-sm-6">
							<input type="text" class="form-control" id="inputEmail3" placeholder="Type your email">
							</div>
						</div>

						<div class="form-group row">
							<label for="inputEmail3" class="col-md-4 text-right col-form-label">Phone#</label>
							<div class="col-sm-6">
							<input type="text" class="form-control" id="inputEmail3" placeholder="Type your phone number">
							</div>
						</div>

						<div class="form-group row">
						<label for="inputEmail3" class="col-md-4 text-right col-form-label">What is the nature of this job?<span>*</span></label>
						<div class="col-sm-6">
						<select class="form-control form-control" aria-label="Default select example">
						<option selected class="form-control">Please select...</option>
						<option value="1">One</option>
						<option value="2">Two</option>
						<option value="3">Three</option>
						</select>
						</div>
						</div>


						<div class="form-group row">
						<label for="inputEmail3" class="col-md-4 text-right col-form-label">Type Of Your Book / Genre<span>*</span></label>
						<div class="col-sm-6">
						<div class="form-check">
							<input type="checkbox" class="form-check-input" id="exampleCheck1">
							<label class="form-check-label" for="exampleCheck1">Fiction/Non-Fiction</label>
						</div>
						<div class="form-check">
							<input type="checkbox" class="form-check-input" id="exampleCheck1">
							<label class="form-check-label" for="exampleCheck1">Autobiography/Biography</label>
						</div>
						<div class="form-check">
							<input type="checkbox" class="form-check-input" id="exampleCheck1">
							<label class="form-check-label" for="exampleCheck1">Self-Help</label>
						</div>
						<div class="form-check">
							<input type="checkbox" class="form-check-input" id="exampleCheck1">
							<label class="form-check-label" for="exampleCheck1">Others</label>
						</div>
						</div>
						</div>

					

						<div class="form-group row">
						<label for="inputEmail3" class="col-md-4 text-right col-form-label">Who is your target audience?<span>*</span></label>
						<div class="col-sm-6">
						<select class="form-control form-control" aria-label="Default select example">
						<option selected class="form-control">Please select...</option>
						<option value="1">One</option>
						<option value="2">Two</option>
						<option value="3">Three</option>
						</select>
						</div>
						</div>

						<div class="form-group row">
						<label for="inputEmail3" class="col-md-4 text-right col-form-label">What sort of tone do you want your book to be in?<span>*</span></label>
						<div class="col-sm-6">
						<select class="form-control form-control" aria-label="Default select example">
						<option selected class="form-control">Please select...</option>
						<option value="1">One</option>
						<option value="2">Two</option>
						<option value="3">Three</option>
						</select>
						</div>
						</div>

						<div class="form-group row">
						<label for="inputEmail3" class="col-md-4 text-right col-form-label">Please specify the narrative you would prefer the book to be written in.<span>*</span></label>
						<div class="col-sm-6">
						<select class="form-control form-control" aria-label="Default select example">
						<option selected class="form-control">Please select...</option>
						<option value="1">One</option>
						<option value="2">Two</option>
						<option value="3">Three</option>
						</select>
						</div>
						</div>

						<div class="form-group row">
						<label for="inputEmail3" class="col-md-4 text-right col-form-label">Writing Style<span>*</span></label>
						<div class="col-sm-6">
						<select class="form-control form-control" aria-label="Default select example">
						<option selected class="form-control">Please select...</option>
						<option value="1">One</option>
						<option value="2">Two</option>
						<option value="3">Three</option>
						</select>
						</div>
						</div>


						<div class="form-group row">
						<label for="exampleFormControlTextarea1" class="col-md-4 text-right col-form-label">Title of your book and subtitle, if any:</label>
						<div class="col-sm-6">
						<textarea class="form-control" id="exampleFormControlTextarea1" placeholder="Title..." rows="3"></textarea>
						</div>
						</div>

						<div class="form-group row">
						<label for="exampleFormControlTextarea1" class="col-md-4 text-right col-form-label">Briefly describe your project. What is it about? What direction you wish to take with it?<span>*</span></label>
						<div class="col-sm-6">
						<textarea class="form-control" id="exampleFormControlTextarea1" placeholder="Briefly describe your project.." rows="3"></textarea>
						</div>
						</div>

						<div class="form-group row">
						<label for="exampleFormControlTextarea1" class="col-md-4 text-right col-form-label">Why are you writing this book?<span>*</span></label>
						<div class="col-sm-6">
						<textarea class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
						</div>
						</div>

						<div class="form-group row">
						<label for="exampleFormControlTextarea1" class="col-md-4 text-right col-form-label">Do you have any specific instructions for the writer that you would like to convey?</label>
						<div class="col-sm-6">
						<textarea class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
						</div>
						</div>

						<div class="form-group row">
						<label for="exampleFormControlTextarea1" class="col-md-4 text-right col-form-label">If you would be writing this book, how you would start?</label>
						<div class="col-sm-6">
						<textarea class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
						</div>
						</div>

						<div class="form-group row">
						<label for="exampleFormControlTextarea1" class="col-md-4 text-right col-form-label">Are there any particular books, research sources, memoirs, and scripts that you want the writer to consider while developing your book?</label>
						<div class="col-sm-6">
						<textarea class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
						</div>
						</div>


						<div class="form-group row">
						<label for="inputEmail3" class="col-md-4 text-right col-form-label">Deadline<span>*</span></label>
						<div class="col-sm-6">
						<input type="date" class="form-control" id="exampleCheck1">
						</div>
						</div>

						<div class="form-group row">
							<label for="inputEmail3" class="col-md-4 text-right col-form-label">Book Size</label>
							<div class="col-sm-6">
							<input type="text" class="form-control" id="inputEmail3">
							</div>
						</div>

						<div class="form-group row">
							<label for="inputEmail3" class="col-md-4 text-right col-form-label">No. of Pages<span>*</span></label>
							<div class="col-sm-6">
							<input type="number" class="form-control" id="inputEmail3">
							</div>
						</div>

						<div class="form-group row">
							<label for="inputEmail3" class="col-md-4 text-right col-form-label">Author<span>*</span></label>
							<div class="col-sm-6">
							<input type="text" class="form-control" id="inputEmail3" placeholder="Author">
							</div>
						</div>


						<div class="form-group row">
							<label for="inputEmail3" class="col-md-4 text-right col-form-label">Total Chapters</label>
							<div class="col-sm-2">
							<input type="number" class="form-control" id="inputEmail3">
							</div>
							<div class="col-sm-2">
							<a href="#" id="addmore" class="add_input"><i class="fa-solid fa-plus"></i></a></div>
							</div>


						<div class="form-group row">
							<label for="inputEmail3" class="col-md-4 text-right col-form-label">Chapter Name</label>
							<div class="col-sm-6">
							<input type="text" name="fname" class="form-control" id="inputEmail3" placeholder="Chapter Name">
							</div>
						</div>

						<div class="form-group row">
							<label for="inputEmail3" class="col-md-4 text-right col-form-label">Chapter Details</label>
							<div class="col-sm-6">
							<input type="text" name="lname" class="form-control" id="inputEmail3" placeholder="Chapter Details">
							</div>
						</div>

						<div class="form-group row">
							<label for="inputEmail3" class="col-md-4 text-right col-form-label">Upload File (Book Cover Reference (if any))</label>
							<div class="col-sm-6">
							<input type="file" class="form-control" id="inputEmail3">
							</div>
						</div>

						<div class="form-group row">
						<label for="exampleFormControlTextarea1" class="col-md-4 text-right col-form-label">Reference Links</label>
						<div class="col-sm-6">
						<textarea class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
						</div>
						</div>

						<div class="form-group row">
						<label for="exampleFormControlTextarea1" class="col-md-4 text-right col-form-label">Other Information</label>
						<div class="col-sm-6">
						<textarea class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
						</div>
						</div>


						<div class="form-group row">
						<label for="inputEmail3" class="col-md-4 text-right col-form-label"><input type="checkbox" class="form-check-input" id="exampleCheck1">I Have Accepted All <a href="#">Terms & Conditions</a></label>
						<div class="col-sm-6">
							<button class="form-control submit-btn">Submit</button>
						</div>
						</div>
					</diV>	
				</div>
			</div>

			<script>
			$(document).ready(function() {
			$("#addmore").click(function() {
				$("#req_input").append('<div class="required_inp"><input name="fname" placeholder="Text Field 1" type="text"><input name="lname" placeholder="Text Field 2" type="text">' + '<input type="button" class="inputRemove" value="Remove"/></div>');
			});
			$('body').on('click','.inputRemove',function() {
				$(this).parent('div.required_inp').remove()
			});
			});
			</script>


<?php include 'footer.php';?>
